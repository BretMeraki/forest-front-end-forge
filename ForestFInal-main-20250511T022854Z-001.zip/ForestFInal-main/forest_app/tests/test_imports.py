"""
Import verification test module.
"""

import logging
import unittest

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class TestImports(unittest.TestCase):
    """Test case for verifying imports."""
    
    def test_core_imports(self):
        """Test importing core components."""
        try:
            from forest_app.core import (
                ReflectionProcessor,
                CompletionProcessor,
                HTAService,
                ComponentStateManager,
                SemanticMemoryManager,
                MemorySnapshot,
                clamp01,
                SilentScoring,
                HarmonicRouting
            )
            logger.info("✓ Core package imports successful")
        except ImportError as e:
            logger.error(f"✗ Core package import failed: {e}")
            raise
            
    def test_direct_package_imports(self):
        """Test importing from specific packages."""
        try:
            from forest_app.core.processors import ReflectionProcessor
            from forest_app.core.services import HTAService
            logger.info("✓ Direct package imports successful")
        except ImportError as e:
            logger.error(f"✗ Direct package import failed: {e}")
            raise
            
    def test_module_imports(self):
        """Test importing modules."""
        try:
            from forest_app.modules.seed import SeedManager
            from forest_app.modules.logging_tracking import TaskFootprintLogger
            from forest_app.modules.task_engine import TaskEngine
            logger.info("✓ Module imports successful")
        except ImportError as e:
            logger.error(f"✗ Module import failed: {e}")
            raise
            
    def test_integration_imports(self):
        """Test importing integrations."""
        try:
            from forest_app.integrations.llm import LLMClient
            logger.info("✓ Integration imports successful")
        except ImportError as e:
            logger.error(f"✗ Integration import failed: {e}")
            raise
            
    def test_container_imports(self):
        """Test importing containers."""
        try:
            from forest_app.containers import Container
            logger.info("✓ Container imports successful")
        except ImportError as e:
            logger.error(f"✗ Container import failed: {e}")
            raise

if __name__ == '__main__':
    unittest.main() 