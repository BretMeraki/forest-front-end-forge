"""
LLM Service Abstraction Layer for Forest OS.

This module implements the [MCP-LLM Vision - Arch] PRD requirement by providing
a clean abstraction layer for different LLM providers. The main component is
the BaseLLMService abstract base class, which defines a standard interface for
interacting with LLMs regardless of the specific provider.

For the MVP, Google Gemini is used as the default LLM provider via the
GoogleGeminiService concrete implementation.
"""

from abc import ABC, abstractmethod
import json
import logging
from typing import Dict, Any, Optional, Type, TypeVar, Union, List, Generic

from pydantic import BaseModel

# Ensure we try to import Google Generative AI library
try:
    import google.generativeai as genai
    from google.generativeai.types import (
        ContentDict, GenerationConfig, GenerateContentResponse,
        HarmBlockThreshold, HarmCategory,
    )
    from google.generativeai import protos
    from google.api_core import exceptions as google_api_exceptions
    google_import_ok = True
except ImportError:
    logging.getLogger(__name__).critical(
        "Failed to import google.generativeai or related components. "
        "Install with: pip install google-generativeai"
    )
    google_import_ok = False
    # We'll define dummy classes for type checking

# Import configurations
try:
    from forest_app.config.settings import settings
    settings_import_ok = True
except ImportError:
    logging.getLogger(__name__).warning(
        "Failed to import settings. Using default configuration values."
    )
    settings_import_ok = False

# Set up logging
logger = logging.getLogger(__name__)

# Type for Pydantic model that can be used for response validation
T = TypeVar('T', bound=BaseModel)

# Exception classes for the LLM service layer
class LLMServiceError(Exception):
    """Base exception class for LLM service errors."""
    pass

class LLMConfigError(LLMServiceError):
    """Error in LLM service configuration."""
    pass

class LLMRequestError(LLMServiceError):
    """Error making a request to the LLM service."""
    pass

class LLMResponseError(LLMServiceError):
    """Error processing a response from the LLM service."""
    pass


class BaseLLMService(ABC, Generic[T]):
    """
    Abstract base class defining the interface for LLM services.
    
    This class provides a standard interface for interacting with different LLM 
    providers. Concrete subclasses must implement the abstract methods to interact 
    with specific LLM providers.
    """
    
    @abstractmethod
    async def generate_text(
        self, 
        prompt: str, 
        temperature: float = 0.7,
        max_tokens: int = 1000
    ) -> str:
        """
        Generate text from the LLM based on a prompt.
        
        Args:
            prompt: The prompt to send to the LLM
            temperature: The temperature parameter (creativity)
            max_tokens: The maximum number of tokens to generate
            
        Returns:
            The generated text as a string
            
        Raises:
            LLMServiceError: If there's an error generating the text
        """
        pass
    
    @abstractmethod
    async def generate_json(
        self, 
        prompt: str, 
        response_model: Type[T],
        temperature: float = 0.7,
        max_tokens: int = 1000,
        schema: Optional[Dict[str, Any]] = None
    ) -> T:
        """
        Generate JSON from the LLM based on a prompt and validate it against a Pydantic model.
        
        Args:
            prompt: The prompt to send to the LLM
            response_model: A Pydantic model class that the response should conform to
            temperature: The temperature parameter (creativity)
            max_tokens: The maximum number of tokens to generate
            schema: Optional JSON schema to guide the LLM's response format
            
        Returns:
            A validated instance of the response_model Pydantic class
            
        Raises:
            LLMServiceError: If there's an error generating the JSON or it doesn't match the schema
        """
        pass
    
    @abstractmethod
    async def generate_structured_output(
        self, 
        prompt: str, 
        structure_name: str,
        structure_description: str,
        temperature: float = 0.7,
        max_tokens: int = 1000
    ) -> Dict[str, Any]:
        """
        Generate structured output from the LLM based on a prompt and a description of the structure.
        
        Args:
            prompt: The prompt to send to the LLM
            structure_name: A name for the structure (e.g., "TaskList")
            structure_description: A description of the fields in the structure
            temperature: The temperature parameter (creativity)
            max_tokens: The maximum number of tokens to generate
            
        Returns:
            A dictionary representing the structured output
            
        Raises:
            LLMServiceError: If there's an error generating the structured output
        """
        pass


class GoogleGeminiService(BaseLLMService):
    """
    Google Gemini implementation of the BaseLLMService interface.
    
    This class uses the Google Generative AI library to interact with the Gemini models.
    """
    
    def __init__(
        self, 
        api_key: Optional[str] = None,
        model_name: str = "gemini-1.5-flash-latest",
        safety_settings: Optional[Dict] = None
    ):
        """
        Initialize the GoogleGeminiService.
        
        Args:
            api_key: The API key for Google Generative AI. If None, it will be loaded from settings.
            model_name: The name of the Gemini model to use
            safety_settings: Optional safety settings for the model
            
        Raises:
            LLMConfigError: If the API key is missing or there's an error configuring the library
        """
        if not google_import_ok:
            raise ImportError("google.generativeai library is required but not found.")
            
        # Get the API key from settings if not provided
        self.api_key = api_key
        if not self.api_key:
            if settings_import_ok and hasattr(settings, "GOOGLE_API_KEY"):
                self.api_key = settings.GOOGLE_API_KEY
            else:
                raise LLMConfigError("Google API key is required but was not provided.")
                
        # Default model names
        self.model_name = model_name
        if settings_import_ok and hasattr(settings, "GEMINI_MODEL_NAME"):
            self.model_name = settings.GEMINI_MODEL_NAME
            
        # Configure the Google Generative AI library
        try:
            genai.configure(api_key=self.api_key)
            logger.info(f"Google Gemini configured with model: {self.model_name}")
        except Exception as e:
            raise LLMConfigError(f"Failed to configure Google Generative AI: {e}")
            
        # Set up safety settings
        self.safety_settings = safety_settings or {
            HarmCategory.HARM_CATEGORY_HARASSMENT: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
            HarmCategory.HARM_CATEGORY_HATE_SPEECH: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
            HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
            HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
        } if google_import_ok else {}
    
    def _get_model(self):
        """Get the Gemini model instance."""
        try:
            return genai.GenerativeModel(self.model_name)
        except Exception as e:
            raise LLMConfigError(f"Failed to create Gemini model instance: {e}")
    
    def _create_generation_config(
        self, 
        temperature: float = 0.7,
        max_tokens: int = 1000,
        json_mode: bool = False
    ) -> GenerationConfig:
        """Create a GenerationConfig object for the Gemini model."""
        return GenerationConfig(
            temperature=temperature,
            max_output_tokens=max_tokens,
            top_p=1.0,
            top_k=32,
            response_mime_type="application/json" if json_mode else "text/plain",
        )
    
    def _process_response(self, response: GenerateContentResponse) -> str:
        """
        Process the raw response from the Gemini API.
        
        Args:
            response: The raw response from the Gemini API
            
        Returns:
            The text content of the response
            
        Raises:
            LLMResponseError: If the response is blocked or empty
        """
        if not response.candidates:
            raise LLMResponseError("No response candidates returned from Gemini API.")
            
        candidate = response.candidates[0]
        
        # Check for blocking due to safety concerns
        if hasattr(candidate, 'finish_reason'):
            if candidate.finish_reason == protos.Candidate.FinishReason.SAFETY:
                raise LLMResponseError("Response was blocked due to safety concerns.")
            elif candidate.finish_reason == protos.Candidate.FinishReason.RECITATION:
                logger.warning("Response may contain recitation/copying from training data.")
                
        # Extract the text content
        if not candidate.content.parts:
            raise LLMResponseError("Response content is empty.")
            
        text = candidate.content.parts[0].text
        if not text or text.strip() == "":
            raise LLMResponseError("Response text is empty or only whitespace.")
            
        return text
    
    async def generate_text(
        self, 
        prompt: str, 
        temperature: float = 0.7,
        max_tokens: int = 1000
    ) -> str:
        """
        Generate text from the Gemini model.
        
        Args:
            prompt: The prompt to send to the model
            temperature: The temperature parameter (creativity)
            max_tokens: The maximum number of tokens to generate
            
        Returns:
            The generated text as a string
            
        Raises:
            LLMServiceError: If there's an error generating the text
        """
        try:
            model = self._get_model()
            generation_config = self._create_generation_config(
                temperature=temperature,
                max_tokens=max_tokens,
                json_mode=False
            )
            
            response = model.generate_content(
                prompt,
                generation_config=generation_config,
                safety_settings=self.safety_settings
            )
            
            return self._process_response(response)
        except LLMServiceError:
            # Re-raise LLMServiceError subclasses
            raise
        except Exception as e:
            raise LLMRequestError(f"Error generating text from Gemini: {e}")
    
    async def generate_json(
        self, 
        prompt: str, 
        response_model: Type[T],
        temperature: float = 0.7,
        max_tokens: int = 1000,
        schema: Optional[Dict[str, Any]] = None
    ) -> T:
        """
        Generate JSON from the Gemini model and validate it against a Pydantic model.
        
        Args:
            prompt: The prompt to send to the model
            response_model: A Pydantic model class that the response should conform to
            temperature: The temperature parameter (creativity)
            max_tokens: The maximum number of tokens to generate
            schema: Optional JSON schema to guide the model's response format
            
        Returns:
            A validated instance of the response_model Pydantic class
            
        Raises:
            LLMServiceError: If there's an error generating the JSON or it doesn't match the schema
        """
        # Append schema information to the prompt if provided
        if schema:
            schema_json = json.dumps(schema, indent=2)
            prompt = f"{prompt}\n\nOutput should follow this JSON schema:\n{schema_json}"
        else:
            # Use Pydantic model to generate schema
            model_schema = response_model.model_schema()
            schema_json = json.dumps(model_schema, indent=2)
            prompt = f"{prompt}\n\nOutput should follow this JSON schema:\n{schema_json}"
        
        try:
            model = self._get_model()
            generation_config = self._create_generation_config(
                temperature=temperature,
                max_tokens=max_tokens,
                json_mode=True
            )
            
            response = model.generate_content(
                prompt,
                generation_config=generation_config,
                safety_settings=self.safety_settings
            )
            
            text = self._process_response(response)
            
            # Try to parse JSON from the response
            try:
                # Clean up the response to handle potential non-JSON prefix/suffix
                json_start = text.find('{')
                json_end = text.rfind('}') + 1
                
                if json_start >= 0 and json_end > json_start:
                    json_text = text[json_start:json_end]
                    data = json.loads(json_text)
                else:
                    raise ValueError("No JSON object found in response")
                
                # Validate against Pydantic model
                try:
                    return response_model.model_validate(data)
                except Exception as e:
                    raise LLMResponseError(f"Response does not match schema: {e}")
                    
            except json.JSONDecodeError as e:
                raise LLMResponseError(f"Failed to parse JSON from response: {e}")
                
        except LLMServiceError:
            # Re-raise LLMServiceError subclasses
            raise
        except Exception as e:
            raise LLMRequestError(f"Error generating JSON from Gemini: {e}")
    
    async def generate_structured_output(
        self, 
        prompt: str, 
        structure_name: str,
        structure_description: str,
        temperature: float = 0.7,
        max_tokens: int = 1000
    ) -> Dict[str, Any]:
        """
        Generate structured output from the Gemini model.
        
        Args:
            prompt: The prompt to send to the model
            structure_name: A name for the structure (e.g., "TaskList")
            structure_description: A description of the fields in the structure
            temperature: The temperature parameter (creativity)
            max_tokens: The maximum number of tokens to generate
            
        Returns:
            A dictionary representing the structured output
            
        Raises:
            LLMServiceError: If there's an error generating the structured output
        """
        # Create a prompt that describes the expected structure
        structured_prompt = (
            f"{prompt}\n\n"
            f"Please return a JSON object representing a {structure_name} with the following structure:\n"
            f"{structure_description}\n\n"
            f"Return only valid JSON without any explanation or additional text."
        )
        
        try:
            model = self._get_model()
            generation_config = self._create_generation_config(
                temperature=temperature,
                max_tokens=max_tokens,
                json_mode=True
            )
            
            response = model.generate_content(
                structured_prompt,
                generation_config=generation_config,
                safety_settings=self.safety_settings
            )
            
            text = self._process_response(response)
            
            # Try to parse JSON from the response
            try:
                # Clean up the response to handle potential non-JSON prefix/suffix
                json_start = text.find('{')
                json_end = text.rfind('}') + 1
                
                if json_start >= 0 and json_end > json_start:
                    json_text = text[json_start:json_end]
                    return json.loads(json_text)
                else:
                    raise ValueError("No JSON object found in response")
                    
            except json.JSONDecodeError as e:
                raise LLMResponseError(f"Failed to parse JSON from response: {e}")
                
        except LLMServiceError:
            # Re-raise LLMServiceError subclasses
            raise
        except Exception as e:
            raise LLMRequestError(f"Error generating structured output from Gemini: {e}")


# Factory function to create the appropriate LLM service based on configuration
def create_llm_service(provider: str = "gemini", **kwargs) -> BaseLLMService:
    """
    Create an LLM service instance based on the specified provider.
    
    Args:
        provider: The LLM provider to use ("gemini" for Google Gemini)
        **kwargs: Additional configuration parameters for the service
        
    Returns:
        An instance of a BaseLLMService implementation
        
    Raises:
        ValueError: If the provider is not supported
    """
    if provider.lower() == "gemini":
        return GoogleGeminiService(**kwargs)
    else:
        raise ValueError(f"Unsupported LLM provider: {provider}")
