"""
Pydantic models for the Roadmap Manifest, which serves as the single source of truth
for the HTA (Hierarchical Task Analysis) tree and its evolution.

The Roadmap Manifest consists of:
- A collection of RoadmapSteps with dependencies
- Metadata about the overall tree structure
- Status tracking for steps that are synchronized with HTANodes

This module implements the [Manifest-HTA - Core] PRD requirement where the 
RoadmapManifest is the single source of truth for the HTA tree.
"""

from pydantic import BaseModel, Field, validator
from datetime import datetime
from typing import List, Optional, Dict, Any, Literal
from uuid import UUID, uuid4


class RoadmapStep(BaseModel):
    """
    A single step in the roadmap manifest.
    
    Each step represents a task or action to be taken, and can have dependencies
    on other steps in the manifest. The status field is synchronized with the 
    corresponding HTANode's status.
    
    [LeanMVP - Simplify]: Focusing on essential fields for MVP, deferring estimated_duration and semantic_context.
    """
    # Core Identification & Content
    id: UUID = Field(default_factory=uuid4, description="Unique identifier for the step")
    title: str = Field(description="Title of the roadmap step")
    description: str = Field(description="Detailed description of the step")
    
    # Status Management
    status: Literal["pending", "in_progress", "completed", "deferred", "cancelled"] = "pending"
    
    # Dependency Management
    dependencies: List[UUID] = Field(
        default_factory=list, 
        description="List of step IDs this step depends on"
    )
    
    # Priority & Metadata
    priority: Literal["high", "medium", "low"] = "medium"
    hta_metadata: Dict[str, Any] = Field(
        default_factory=dict, 
        description="Metadata about this step in the HTA structure (e.g., {\"is_major_phase\": true/false})"
    )
    
    # Audit Trail
    created_at: datetime = Field(default_factory=datetime.utcnow, description="Timestamp of step creation")
    updated_at: datetime = Field(default_factory=datetime.utcnow, description="Timestamp of last step update")
    
    @validator('updated_at', always=True)
    def update_updated_at(cls, v):
        return datetime.utcnow()
    
    class Config:
        """Configuration for the model."""
        json_schema_extra = {
            "example": {
                "id": "550e8400-e29b-41d4-a716-446655440000",
                "title": "Conduct market research",
                "description": "Gather information about target audience, competitors, and market trends.",
                "dependencies": [],
                "priority": "high",
                "status": "pending",
                "hta_metadata": {"is_major_phase": True}
            }
        }


class RoadmapManifest(BaseModel):
    """
    The manifest that serves as the single source of truth for the HTA tree.
    
    This model contains all the steps in the roadmap, with their dependencies and status.
    When the HTA tree is updated, the manifest is updated to reflect those changes,
    ensuring consistency between the two.
    
    [LeanMVP - Simplify]: Focusing on essential fields for MVP, deferring some context capture fields.
    """
    # Core Identification
    id: UUID = Field(default_factory=uuid4, description="Unique identifier for the manifest")
    tree_id: UUID = Field(description="Corresponds to HTATreeModel.id")
    
    # Versioning - Simplified for MVP
    manifest_version: str = Field(default="1.0", description="Version of the manifest schema")
    
    # Goal Capture - Essential for context
    user_goal: str = Field(description="Primary user goal or objective")
    
    # Q&A Traceability - Keeping basic structure for future expansion
    q_and_a_responses: List[Dict[str, Any]] = Field(
        default_factory=list, 
        description="Recorded clarifying questions and user responses during onboarding"
    )
    
    # Steps Content
    steps: List[RoadmapStep] = Field(default_factory=list)
    
    # Audit Trail
    created_at: datetime = Field(default_factory=datetime.utcnow, description="Timestamp of manifest creation")
    updated_at: datetime = Field(default_factory=datetime.utcnow, description="Timestamp of last manifest update")
    
    @validator('updated_at', always=True)
    def update_updated_at(cls, v):
        return datetime.utcnow()
    
    def get_step_by_id(self, step_id: UUID) -> Optional[RoadmapStep]:
        """
        Find and return a step by its ID.
        
        Args:
            step_id: The UUID of the step to find
            
        Returns:
            The step with the given ID, or None if not found
        """
        for step in self.steps:
            if step.id == step_id:
                return step
        return None
    
    def update_step_status(self, step_id: UUID, new_status: Literal["pending", "in_progress", "completed", "deferred", "cancelled"]) -> bool:
        """
        Update the status of a step and the updated_at timestamp.
        
        Args:
            step_id: The UUID of the step to update
            new_status: The new status to set
            
        Returns:
            True if the step was found and updated, False otherwise
        """
        step = self.get_step_by_id(step_id)
        if step:
            step.status = new_status
            step.updated_at = datetime.utcnow()  # Update the step's timestamp
            self.updated_at = datetime.utcnow()  # Update the manifest's timestamp
            return True
        return False
    
    def add_step(self, step: RoadmapStep) -> None:
        """
        Add a new step to the manifest and update the updated_at timestamp.
        
        Args:
            step: The step to add
        """
        self.steps.append(step)
        self.updated_at = datetime.utcnow()
        
    def check_circular_dependencies(self) -> List[str]:
        """
        Check for circular dependencies in the manifest steps.
        
        Returns:
            A list of error messages describing any circular dependencies found
        """
        errors = []
        visited = {}  # Maps step_id to visit status: 0=unvisited, 1=in progress, 2=visited
        
        def dfs(step_id):
            # Mark as in-progress
            visited[step_id] = 1
            
            step = self.get_step_by_id(step_id)
            if not step:
                return
            
            for dep_id in step.dependencies:
                if dep_id not in visited:
                    # Not visited yet
                    visited[dep_id] = 0
                    
                if visited.get(dep_id) == 0:
                    # Visit unvisited node
                    if dfs(dep_id):
                        # Propagate cycle detection
                        return True
                elif visited.get(dep_id) == 1:
                    # Found a cycle
                    cycle_step = self.get_step_by_id(dep_id)
                    current_step = self.get_step_by_id(step_id)
                    if cycle_step and current_step:
                        errors.append(
                            f"Circular dependency detected: '{current_step.title}' ({step_id}) "
                            f"depends on '{cycle_step.title}' ({dep_id}) which creates a cycle."
                        )
                    return True
            
            # Mark as visited
            visited[step_id] = 2
            return False
        
        # Check each step that hasn't been visited
        for step in self.steps:
            if step.id not in visited:
                visited[step.id] = 0
                dfs(step.id)
        
        return errors
