# forest_app/processors/completion_processor.py (CORRECTED IMPORT FOR HTASERVICE)

import logging
import inspect
from typing import Optional, Dict, Any, List, TYPE_CHECKING
from sqlalchemy.orm import Session  # Needed for type hint if passed to logger
import json
from datetime import datetime

# Core imports with error handling
try:
    from forest_app.core.snapshot import MemorySnapshot
    from forest_app.core.utils import clamp01
    from forest_app.core.services import HTAService, SemanticMemoryManager
    from forest_app.modules.xp_mastery import XPMastery
    from forest_app.modules.task_engine import TaskEngine
    from forest_app.modules.logging_tracking import TaskFootprintLogger
    from forest_app.integrations.llm import LLMClient
except ImportError as e:
    logging.getLogger(__name__).error(f"Failed to import required modules: {e}")
    # Define dummy classes if imports fail
    class MemorySnapshot: pass
    class HTAService: pass
    class SemanticMemoryManager: pass
    class XPMastery: pass
    class TaskEngine: pass
    class TaskFootprintLogger: pass
    class LLMClient: pass
    def clamp01(x): return x

# Feature flags with error handling
try:
    from forest_app.core.feature_flags import Feature, is_enabled
except ImportError:
    def is_enabled(feature): return False
    class Feature:
        CORE_HTA = "FEATURE_ENABLE_CORE_HTA"
        XP_MASTERY = "FEATURE_ENABLE_XP_MASTERY"
        # Add others if needed for checks within this processor

# Constants with error handling
try:
    from forest_app.config.constants import WITHERING_COMPLETION_RELIEF
except ImportError:
    WITHERING_COMPLETION_RELIEF = 0.1  # Default value if import fails

logger = logging.getLogger(__name__)

# --- Completion Processor Class ---

class CompletionProcessor:
    """Processes task completions with semantic memory integration."""

    def __init__(self, llm_client, hta_service, semantic_memory_manager):
        self.llm_client = llm_client
        self.hta_service = hta_service
        self.semantic_memory_manager = semantic_memory_manager
        self.logger = logging.getLogger(__name__)

    async def process_completion(self, 
                               task_id: str, 
                               completion_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process a task completion with semantic memory integration.
        
        Args:
            task_id: The ID of the completed task
            completion_data: Data about the completion including summary, status, etc.
        """
        try:
            # Query relevant task memories
            relevant_memories = await self.semantic_memory_manager.query_memories(
                query=completion_data.get("summary", ""),
                k=3,
                event_types=["task_completion"]
            )
            
            # Build memory context
            memory_context = self._build_memory_context(relevant_memories)
            
            # Update HTA with completion and memory context
            hta_result = await self.hta_service.update_task_completion(
                task_id=task_id,
                completion_data={
                    **completion_data,
                    "memory_context": memory_context
                }
            )
            
            # Generate completion insights
            insights = await self._generate_completion_insights(
                task_id=task_id,
                completion_data=completion_data,
                hta_result=hta_result,
                memory_context=memory_context
            )
            
            return {
                "task_id": task_id,
                "hta_result": hta_result,
                "insights": insights,
                "relevant_memories": relevant_memories
            }
            
        except Exception as e:
            self.logger.error(f"Error processing task completion: {e}")
            raise

    def _build_memory_context(self, memories: List[Dict[str, Any]]) -> str:
        """Build a context string from relevant task memories."""
        if not memories:
            return ""
            
        context_parts = ["Previous related task completions:"]
        for memory in memories:
            timestamp = datetime.fromisoformat(memory.get("timestamp", "")).strftime("%Y-%m-%d")
            content = memory.get("content", "")
            metadata = memory.get("metadata", {})
            context_parts.append(f"- [{timestamp}] {content}")
            if metadata.get("learnings"):
                context_parts.append(f"  Learnings: {metadata['learnings']}")
            
        return "\n".join(context_parts)

    async def _generate_completion_insights(self,
                                         task_id: str,
                                         completion_data: Dict[str, Any],
                                         hta_result: Dict[str, Any],
                                         memory_context: str) -> List[str]:
        """Generate insights about the task completion using LLM."""
        prompt = f"""
        Task Completion:
        - ID: {task_id}
        - Summary: {completion_data.get('summary', '')}
        - Status: {completion_data.get('status', '')}
        
        HTA Update Result:
        {json.dumps(hta_result)}
        
        Memory Context:
        {memory_context}
        
        Based on this task completion and historical context, generate insights about:
        1. Task completion patterns
        2. Progress towards goals
        3. Learning opportunities
        """
        
        response = await self.llm_client.generate(prompt)
        
        # Parse insights from response
        insights = [line.strip() for line in response.split("\n") if line.strip()]
        return insights
