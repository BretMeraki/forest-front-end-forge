# forest_app/core/services/hta_service.py

import logging
import json
from typing import Optional, Dict, Any, List, TYPE_CHECKING
from datetime import datetime, timezone

# Core imports with error handling
try:
    from forest_app.core.snapshot import MemorySnapshot
    from forest_app.modules.hta_tree import HTATree, HTANode
    from forest_app.modules.seed import SeedManager, Seed
    from forest_app.core.services import SemanticMemoryManager
    from forest_app.integrations.llm import (
        LLMClient,
        HTAEvolveResponse,
        DistilledReflectionResponse,
        LLMError,
        LLMValidationError
    )
    from forest_app.modules.hta_models import HTANodeModel
except ImportError as e:
    logging.getLogger(__name__).error(f"Failed to import required modules: {e}")
    # Define dummy classes if imports fail
    class MemorySnapshot: pass
    class HTATree: pass
    class HTANode: pass
    class SeedManager: pass
    class Seed: pass
    class SemanticMemoryManager: pass
    class LLMClient: pass
    class HTAEvolveResponse: pass
    class DistilledReflectionResponse: pass
    class LLMError(Exception): pass
    class LLMValidationError(Exception): pass
    class HTANodeModel: pass

# Feature flags with error handling
try:
    from forest_app.core.feature_flags import Feature, is_enabled
except ImportError:
    def is_enabled(feature): return True

logger = logging.getLogger(__name__)

class HTAService:
    """Service for managing HTA (Hierarchical Task Analysis) with semantic memory integration."""

    def __init__(self, llm_client, semantic_memory_manager):
        self.llm_client = llm_client
        self.semantic_memory_manager = semantic_memory_manager
        self.logger = logging.getLogger(__name__)
        self.task_hierarchies: Dict[str, Dict[str, Any]] = {}
        
        # Basic dependency checks
        if not isinstance(self.llm_client, LLMClient):
            logger.critical("HTAService initialized with invalid LLMClient!")
        if not isinstance(self.semantic_memory_manager, SemanticMemoryManager):  # Fixed type check
            logger.critical("HTAService initialized with invalid SemanticMemoryManager!")
            
        logger.info("HTAService initialized with dependencies.")
        
    async def initialize_task_hierarchy(self, task_id: str, hierarchy_data: Dict[str, Any]) -> None:
        """
        Initialize a task hierarchy for a given task ID.
        
        Args:
            task_id: Unique identifier for the task
            hierarchy_data: Dictionary containing the task hierarchy structure
        """
        self.task_hierarchies[task_id] = hierarchy_data
        logger.info(f"Initialized HTA hierarchy for task {task_id}")
        
    async def update_task_state(self, task_id: str, state_data: Dict[str, Any]) -> None:
        """
        Update the state of a task in the hierarchy.
        
        Args:
            task_id: Unique identifier for the task
            state_data: Dictionary containing the updated state information
        """
        if task_id not in self.task_hierarchies:
            logger.warning(f"Task {task_id} not found in hierarchies")
            return
            
        self.task_hierarchies[task_id].update(state_data)
        logger.debug(f"Updated state for task {task_id}")
        
    async def get_task_hierarchy(self, task_id: str) -> Optional[Dict[str, Any]]:
        """
        Retrieve the task hierarchy for a given task ID.
        
        Args:
            task_id: Unique identifier for the task
            
        Returns:
            Dictionary containing the task hierarchy, or None if not found
        """
        return self.task_hierarchies.get(task_id)

    async def _get_active_seed(self, snapshot: MemorySnapshot) -> Optional[Seed]:
        """Helper to get the primary active seed from the snapshot or SeedManager."""
        # This logic might vary based on how active seed is tracked
        # Option 1: Check snapshot first
        active_seed_id = snapshot.component_state.get("seed_manager", {}).get("active_seed_id")
        if active_seed_id and hasattr(self.semantic_memory_manager, 'get_seed_by_id'):
            try:
                # Assume get_seed_by_id might be async if it involves DB lookups
                seed = await self.semantic_memory_manager.get_seed_by_id(active_seed_id)
                if seed: return seed
            except Exception as e:
                logger.warning(f"Could not get seed by ID {active_seed_id} from snapshot: {e}")

        # Option 2: Fallback to getting the first active seed from SeedManager
        if hasattr(self.semantic_memory_manager, 'get_primary_active_seed'):
             # Assume get_primary_active_seed might be async
            return await self.semantic_memory_manager.get_primary_active_seed()

        logger.warning("Could not determine active seed.")
        return None


    async def load_tree(self, snapshot: MemorySnapshot) -> Optional[HTATree]:
        """
        Loads the HTA tree, prioritizing the version stored in the active Seed,
        falling back to the snapshot's core_state if necessary.
        Returns an HTATree object or None if not found/invalid.
        """
        logger.debug("Attempting to load HTA tree...")
        current_hta_dict: Optional[Dict] = None
        active_seed = await self._get_active_seed(snapshot)

        # Priority 1: Load from active seed
        if active_seed and hasattr(active_seed, 'hta_tree') and isinstance(active_seed.hta_tree, dict) and active_seed.hta_tree.get('root'):
            logger.debug(f"Loading HTA tree from active seed ID: {getattr(active_seed, 'seed_id', 'N/A')}")
            current_hta_dict = active_seed.hta_tree
        # Priority 2: Load from snapshot core_state
        elif isinstance(snapshot.core_state, dict) and snapshot.core_state.get('hta_tree'):
            logger.warning("Loading HTA tree from snapshot core_state (fallback).") # Log as warning - Seed should ideally be source of truth
            current_hta_dict = snapshot.core_state.get('hta_tree')
        else:
            logger.warning("Could not find HTA tree dictionary in active seed or snapshot core_state.")
            return None

        # Parse the dictionary into an HTATree object
        if current_hta_dict and isinstance(current_hta_dict, dict):
            try:
                tree = HTATree.from_dict(current_hta_dict)
                if tree and tree.root:
                    logger.info(f"Successfully loaded HTA tree with root: {tree.root.id} - '{tree.root.title}'")
                    return tree
                else:
                    logger.error("Failed to parse valid HTATree object from loaded dictionary (root missing?).")
                    return None
            except ValueError as ve:
                logger.error(f"ValueError parsing HTA tree dictionary: {ve}")
                return None
            except Exception as e:
                logger.exception(f"Unexpected error parsing HTA tree dictionary: {e}")
                return None
        else:
            logger.error("Loaded HTA data is not a valid dictionary.")
            return None


    async def save_tree(self, snapshot: MemorySnapshot, tree: HTATree) -> bool:
        """
        Saves the current state of the HTATree object back to the active Seed
        and the snapshot's core_state.

        Args:
            snapshot: The MemorySnapshot object (its core_state will be updated).
            tree: The HTATree object to save.

        Returns:
            True if saving was successful (at least to the snapshot), False otherwise.
        """
        if not tree or not tree.root:
            logger.error("Cannot save HTA tree: Tree object or root node is missing.")
            return False

        try:
            final_hta_dict_to_save = tree.to_dict()
        except Exception as e:
            logger.exception(f"Failed to serialize HTATree object to dictionary: {e}")
            return False

        if not final_hta_dict_to_save or not final_hta_dict_to_save.get('root'):
             logger.error("Failed to serialize HTA tree or root node is missing in dict.")
             return False

        # 1. Update Snapshot Core State (Primary target)
        try:
            if not hasattr(snapshot, 'core_state') or not isinstance(snapshot.core_state, dict):
                snapshot.core_state = {}
            snapshot.core_state['hta_tree'] = final_hta_dict_to_save
            logger.info("Updated HTA tree in snapshot core_state.")
            snapshot_save_ok = True
        except Exception as e:
            logger.exception(f"Failed to update HTA tree in snapshot core_state: {e}")
            snapshot_save_ok = False # Still try to save to seed

        # 2. Update Active Seed (Secondary, Source of Truth)
        seed_save_ok = False
        active_seed = await self._get_active_seed(snapshot)
        if active_seed and hasattr(self.semantic_memory_manager, 'update_seed'):
            try:
                # Assume update_seed is async if it interacts with DB
                success = await self.semantic_memory_manager.update_seed(
                    active_seed.seed_id,
                    hta_tree=final_hta_dict_to_save
                )
                if success:
                    logger.info(f"Successfully updated HTA tree in active seed ID: {active_seed.seed_id}")
                    seed_save_ok = True
                else:
                    logger.error(f"SeedManager failed to update HTA tree for seed ID: {active_seed.seed_id}")
            except Exception as seed_update_err:
                logger.exception(f"Failed to update seed {active_seed.seed_id} with final HTA: {seed_update_err}")
        elif not active_seed:
            logger.error("Cannot save HTA to seed: Active seed not found.")
        else: # SeedManager missing method
             logger.error("Cannot save HTA to seed: Injected SeedManager lacks update_seed method.")

        # Return overall success (prioritize snapshot save)
        return snapshot_save_ok


    def update_node_status(self, tree: HTATree, node_id: str, new_status: str) -> bool:
        """
        Updates the status of a specific node within the tree object and triggers propagation.
        Note: This modifies the tree object in place. Saving must be done separately.

        Args:
            tree: The HTATree object to modify.
            node_id: The ID of the node to update.
            new_status: The new status string (e.g., "completed", "pending").

        Returns:
            True if the node was found and status potentially updated, False otherwise.
        """
        if not tree or not tree.root:
            logger.error("Cannot update node status: HTATree object is invalid.")
            return False

        node = tree.find_node_by_id(node_id)
        if node:
            logger.info(f"Updating status for node '{node.title}' ({node_id}) to '{new_status}'.")
            tree.update_node_status(node_id, new_status) # This handles propagation
            return True
        else:
            logger.warning(f"Cannot update status: Node with id '{node_id}' not found in tree.")
            return False


    async def evolve_tree(self, tree: HTATree, reflections: List[str]) -> Optional[HTATree]:
        """
        Handles the HTA evolution process using the LLM client.

        Args:
            tree: The current HTATree object.
            reflections: List of user reflections from the completed batch.

        Returns:
            A new HTATree object with the evolved structure if successful and valid,
            otherwise None.
        """
        if not tree or not tree.root:
            logger.error("Cannot evolve HTA: Initial tree is invalid.")
            return None
        if not isinstance(self.llm_client, LLMClient) or type(self.llm_client).__name__ == 'DummyService':
            logger.error("Cannot evolve HTA: LLMClient is invalid or dummy.")
            return None

        evolution_goal = "Previous task batch complete. Re-evaluate the plan and suggest next steps." # Default goal

        # 1. (Optional) Distill reflections
        if reflections and hasattr(self.llm_client, 'distill_reflections'):
            logger.info(f"Distilling {len(reflections)} reflections for evolution goal...")
            try:
                distilled_response: Optional[DistilledReflectionResponse] = await self.llm_client.distill_reflections(
                    reflections=reflections
                )
                if distilled_response and distilled_response.distilled_text:
                    evolution_goal = distilled_response.distilled_text
                    logger.info(f"Using distilled reflection as evolution goal: '{evolution_goal[:100]}...'")
                else:
                    logger.warning("Reflection distillation failed or returned empty text. Using default goal.")
            except Exception as distill_err:
                logger.exception(f"Error during reflection distillation: {distill_err}. Using default goal.")
        elif not reflections:
            logger.info("No reflections provided for evolution. Using default goal.")

        # 2. Call LLM for evolution
        try:
            current_hta_json = json.dumps(tree.to_dict()) # Serialize current tree
            logger.debug(f"Calling request_hta_evolution. Goal: '{evolution_goal[:100]}...'")

            evolved_hta_response: Optional[HTAEvolveResponse] = await self.llm_client.request_hta_evolution(
                current_hta_json=current_hta_json,
                evolution_goal=evolution_goal,
                # use_advanced_model=False # TODO: Consider making this configurable
            )

            # 3. Validate and Process LLM Response
            if not isinstance(evolved_hta_response, HTAEvolveResponse) or not evolved_hta_response.hta_root:
                 log_response = evolved_hta_response if len(str(evolved_hta_response)) < 500 else str(type(evolved_hta_response))
                 logger.error(f"Failed to get valid evolved HTA from LLM. Type: {type(evolved_hta_response)}. Response: {log_response}")
                 return None # Evolution failed

            # Check root ID match (critical!)
            llm_root_id = getattr(evolved_hta_response.hta_root, 'id', 'LLM_MISSING_ID')
            original_root_id = getattr(tree.root, 'id', 'ORIGINAL_MISSING_ID')
            if llm_root_id != original_root_id:
                 logger.error(f"LLM HTA evolution root ID mismatch ('{llm_root_id}' vs '{original_root_id}'). Discarding evolved tree.")
                 return None # Evolution result is invalid

            # Convert Pydantic model back to dictionary for HTATree parsing
            # Add extra validation here if needed before dumping
            evolved_hta_root_dict = evolved_hta_response.hta_root.model_dump(mode='json')
            evolved_hta_dict = {'root': evolved_hta_root_dict}

            # Attempt to parse the evolved dictionary back into an HTATree object
            try:
                new_tree = HTATree.from_dict(evolved_hta_dict)
                if new_tree and new_tree.root:
                    logger.info("Successfully received and parsed evolved HTA tree.")
                    return new_tree # Return the new, evolved tree object
                else:
                    logger.error("Failed to re-parse evolved HTA dictionary into valid HTATree object.")
                    return None # Parsing failed
            except ValueError as ve:
                 logger.error(f"ValueError parsing evolved HTA dictionary: {ve}")
                 return None
            except Exception as parse_err:
                 logger.exception(f"Unexpected error parsing evolved HTA dictionary: {parse_err}")
                 return None

        except (LLMError, LLMValidationError) as llm_evolve_err:
            logger.error(f"LLM/Validation Error during HTA evolution request: {llm_evolve_err}")
            return None # Evolution failed
        except Exception as evolve_err:
            logger.exception(f"Unexpected error during HTA evolution process: {evolve_err}")
            return None # Evolution failed

    async def update_task_completion(self, task_id: str, completion_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Update task completion status with semantic memory context.
        
        Args:
            task_id: The ID of the completed task
            completion_data: Data about the completion including memory context
        """
        try:
            # Extract memory context
            memory_context = completion_data.get("memory_context", "")
            
            # Update task status
            update_result = await self._update_task_status(
                task_id=task_id,
                status="completed",
                context=memory_context
            )
            
            # Store completion as semantic memory
            await self.semantic_memory_manager.store_memory(
                event_type="hta_update",
                content=f"Updated task {task_id} status to completed",
                metadata={
                    "task_id": task_id,
                    "update_result": update_result,
                    "timestamp": datetime.now(timezone.utc).isoformat()
                },
                importance=0.5
            )
            
            return update_result
            
        except Exception as e:
            self.logger.error(f"Error updating task completion: {e}")
            raise

    async def _update_task_status(self, 
                                task_id: str, 
                                status: str,
                                context: str = "") -> Dict[str, Any]:
        """Update task status with context."""
        # Implementation depends on your HTA data structure
        pass

    async def get_task_history(self, task_id: str) -> List[Dict[str, Any]]:
        """Get task history from semantic memory."""
        try:
            memories = await self.semantic_memory_manager.query_memories(
                query=f"Get history for task {task_id}",
                k=10,
                event_types=["hta_update", "task_completion"]
            )
            return memories
            
        except Exception as e:
            self.logger.error(f"Error getting task history: {e}")
            raise

    async def analyze_task_patterns(self, task_id: str) -> Dict[str, Any]:
        """Analyze patterns in task history using semantic memory."""
        try:
            # Get task history
            history = await self.get_task_history(task_id)
            
            if not history:
                return {"patterns": [], "insights": []}
            
            # Build analysis prompt
            history_text = "\n".join([
                f"- [{m['timestamp']}] {m['content']}"
                for m in history
            ])
            
            prompt = f"""
            Task History:
            {history_text}
            
            Analyze this task history and identify:
            1. Common patterns in task execution
            2. Potential improvements or optimizations
            3. Learning points from past completions
            """
            
            # Generate analysis
            analysis = await self.llm_client.generate(prompt)
            
            # Parse analysis into structured format
            lines = [l.strip() for l in analysis.split("\n") if l.strip()]
            patterns = []
            insights = []
            current_section = None
            
            for line in lines:
                if "patterns:" in line.lower():
                    current_section = "patterns"
                elif "improvements:" in line.lower():
                    current_section = "improvements"
                elif "learning points:" in line.lower():
                    current_section = "insights"
                elif line.startswith("-") and current_section:
                    if current_section == "patterns":
                        patterns.append(line[1:].strip())
                    elif current_section == "insights":
                        insights.append(line[1:].strip())
            
            return {
                "patterns": patterns,
                "insights": insights
            }
            
        except Exception as e:
            self.logger.error(f"Error analyzing task patterns: {e}")
            raise
